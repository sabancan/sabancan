
1 + 1

2 + 3 * 4

3 ^ 2

exp (1)

sqrt (10)

pi

2*pi*6378

x<-1
y<-2
z<-3
x*y*z

my_vect<- c(1,2,3,4,"a","TRUE")
my_vect

my_vect<-c(0,2,1,5)
my_vect[4]

x<-c(2,0,0,4)
x[-1]
x[1]
x[1] <- 3 ; x
x[-1] = 5;

y<-c(2,0,0,14)
y<9

y[y<9]<-2
y

df<- data.frame(x=1:5,y=c('a','b','c','d','e'))
df1<-data.frame(x=c(1,4,9,10,12),y=c('a','b','c','d','e'))
df1
df[1,c(1,2)]
df[c(2,3),2]
df[c(1,2,3),2]
df[1,]
df[,1]
